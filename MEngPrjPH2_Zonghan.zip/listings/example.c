#include <stdio.h>

void main( void )
{
  puts( "Hello, world!\n" );
}
